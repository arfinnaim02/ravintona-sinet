"""Database models for the restaurant application.

The models defined here represent menu categories, individual menu
items and contact messages submitted via the website. They use
simple field types and avoid unnecessary complexity so they can
easily be managed via custom admin views rather than the default
Django admin interface.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.urls import reverse


class Category(models.Model):
    """A grouping for menu items.

    Categories are displayed on the menu page to help diners find
    items more easily. Categories have an order field so they can
    be arranged manually.
    """

    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "name"]

    def __str__(self) -> str:
        return self.name

    def get_absolute_url(self) -> str:
        return reverse("restaurant:menu") + f"?category={self.slug}"


class MenuItem(models.Model):
    """A single dish or drink available at the restaurant.

    Menu items belong to a category and can carry a list of tags
    and allergens. Tags and allergens are stored as comma
    separated strings to avoid the overhead of many to many
    relations in this simple example. If your menu grows in
    complexity you may wish to normalise these into separate
    tables.
    """

    STATUS_ACTIVE = "active"
    STATUS_HIDDEN = "hidden"
    STATUS_SOLD_OUT = "sold_out"
    STATUS_CHOICES = [
        (STATUS_ACTIVE, "Active"),
        (STATUS_HIDDEN, "Hidden"),
        (STATUS_SOLD_OUT, "Sold Out"),
    ]

    name = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="menu_items")
    price = models.DecimalField(max_digits=6, decimal_places=2)
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to="menu_items/", blank=True, null=True)
    tags = models.CharField(max_length=200, blank=True, help_text="Comma separated list of tags.")
    allergens = models.CharField(max_length=200, blank=True, help_text="Comma separated list of allergens.")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_ACTIVE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name

    def get_tags_list(self) -> list[str]:
        """Return tags as a list of strings."""
        return [t.strip() for t in self.tags.split(",") if t.strip()]

    def get_allergens_list(self) -> list[str]:
        """Return allergens as a list of strings."""
        return [a.strip() for a in self.allergens.split(",") if a.strip()]

    def is_popular(self) -> bool:
        return "popular" in self.get_tags_list()


class ContactMessage(models.Model):
    """A simple contact form submission.

    Stores the sender's name, email and message body. You could
    extend this model to include phone numbers or other metadata
    as needed. Messages are timestamped when created.
    """

    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"Message from {self.name} <{self.email}>"
