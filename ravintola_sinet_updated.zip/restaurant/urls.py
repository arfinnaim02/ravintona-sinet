"""URL definitions for the restaurant application."""

from django.urls import path
from . import views

app_name = "restaurant"

urlpatterns = [
    path("", views.home, name="home"),
    path("menu/", views.menu, name="menu"),
    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),

    # Admin / staff pages
    path("admin/login/", views.admin_login, name="admin_login"),
    path("admin/logout/", views.admin_logout, name="admin_logout"),
    path("admin/dashboard/", views.dashboard, name="dashboard"),
    path("admin/menu/add/", views.add_menu_item, name="add_menu_item"),
]
