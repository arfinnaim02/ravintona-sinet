"""Forms for the restaurant application.

This module defines ModelForm subclasses for creating and editing
menu items as well as a simple contact form and a custom
authentication form. Where appropriate, these forms override
default behaviour to handle storing lists of tags and allergens as
comma separated strings.
"""

from __future__ import annotations

from typing import Any

from django import forms
from django.conf import settings
from django.contrib.auth.forms import AuthenticationForm

from .models import MenuItem, Category, ContactMessage


class MenuItemForm(forms.ModelForm):
    """Form for creating or updating a menu item.

    Presents tag and allergen choices as multi-select checkboxes
    and flattens the selected values into comma separated strings
    on save. The category field is rendered as a simple drop
    down.
    """

    tags = forms.MultipleChoiceField(
        choices=settings.MENU_ITEM_TAGS,
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label="Tags",
    )
    allergens = forms.MultipleChoiceField(
        choices=settings.MENU_ITEM_ALLERGENS,
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label="Allergens",
    )

    class Meta:
        model = MenuItem
        fields = [
            "name",
            "category",
            "price",
            "description",
            "image",
            "tags",
            "allergens",
            "status",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            "status": forms.Select(),
        }

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Prepopulate category choices with active categories
        self.fields["category"].queryset = Category.objects.filter(is_active=True)
        # When editing an existing item, split stored tags/allergens into lists
        instance: MenuItem | None = kwargs.get("instance")
        if instance:
            self.initial["tags"] = instance.get_tags_list()
            self.initial["allergens"] = instance.get_allergens_list()

    def clean_tags(self) -> str:
        tags = self.cleaned_data.get("tags", [])
        return ",".join(tags)

    def clean_allergens(self) -> str:
        allergens = self.cleaned_data.get("allergens", [])
        return ",".join(allergens)


class ContactForm(forms.ModelForm):
    """A simple contact form bound to the ContactMessage model."""

    class Meta:
        model = ContactMessage
        fields = ["name", "email", "message"]
        widgets = {
            "message": forms.Textarea(attrs={"rows": 5}),
        }


class AdminLoginForm(AuthenticationForm):
    """Custom authentication form for the admin login page.

    This subclass primarily exists so that we can customise the
    rendered HTML in the template more easily.
    """

    username = forms.CharField(
        max_length=254,
        widget=forms.TextInput(attrs={
            "autofocus": True,
            "placeholder": "Email or username",
        }),
        label="Email or Username",
    )
    password = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={"placeholder": "Password"}),
    )
