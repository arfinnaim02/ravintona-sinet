"""Views for the restaurant application.

This module contains function based views for both the public
facing pages (home, menu, about, contact) and the custom admin
interface (login, dashboard, add menu item). The admin views are
protected using the login_required decorator and rely on Django's
authentication system for access control.
"""

from __future__ import annotations

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from .forms import MenuItemForm, ContactForm, AdminLoginForm
from .models import Category, MenuItem, ContactMessage


def home(request: HttpRequest) -> HttpResponse:
    """Render the home page.

    The home page features a hero section, highlights and a
    selection of popular dishes. Popular dishes are determined by
    checking for the 'popular' tag on menu items. If there are
    fewer than four popular items the view will display as many as
    are available.
    """
    popular_items = MenuItem.objects.filter(status=MenuItem.STATUS_ACTIVE).filter(
        tags__icontains="popular"
    )[:4]
    categories = Category.objects.filter(is_active=True)
    context = {
        "popular_items": popular_items,
        "categories": categories,
    }
    return render(request, "home.html", context)


def menu(request: HttpRequest) -> HttpResponse:
    """Display the full menu with optional filtering.

    Accepts query parameters `category` (slug) and `tag` to
    filter menu items. Category filtering is exclusive (only one
    category at a time) whereas tag filtering may return items
    containing the specified tag anywhere in their tag list.
    """
    categories = Category.objects.filter(is_active=True)
    category_slug = request.GET.get("category")
    tag_filter = request.GET.get("tag")
    items = MenuItem.objects.filter(status=MenuItem.STATUS_ACTIVE)
    current_category: Category | None = None
    if category_slug:
        current_category = get_object_or_404(Category, slug=category_slug, is_active=True)
        items = items.filter(category=current_category)
    if tag_filter:
        items = items.filter(tags__icontains=tag_filter)
    context = {
        "categories": categories,
        "items": items,
        "current_category": current_category,
        "tag_filter": tag_filter,
    }
    return render(request, "menu.html", context)


def about(request: HttpRequest) -> HttpResponse:
    """Render the about page containing the restaurant story and values."""
    return render(request, "about.html")


def contact(request: HttpRequest) -> HttpResponse:
    """Display a contact form and handle submissions."""
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for your message! We'll get back to you soon.")
            return redirect(reverse("restaurant:contact"))
    else:
        form = ContactForm()
    return render(request, "contact.html", {"form": form})


def admin_login(request: HttpRequest) -> HttpResponse:
    """Display a custom admin login form and authenticate users.

    If the user is already authenticated they are redirected to
    the dashboard. Otherwise we present a login form and perform
    authentication on POST. Upon successful login, staff users are
    redirected to the dashboard.
    """
    if request.user.is_authenticated:
        return redirect(reverse("restaurant:dashboard"))
    if request.method == "POST":
        form = AdminLoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect(reverse("restaurant:dashboard"))
    else:
        form = AdminLoginForm(request)
    return render(request, "admin/login.html", {"form": form})


@login_required
def admin_logout(request: HttpRequest) -> HttpResponse:
    """Log the currently authenticated user out and redirect to login."""
    logout(request)
    return redirect(reverse("restaurant:admin_login"))


@login_required
def dashboard(request: HttpRequest) -> HttpResponse:
    """Render the admin dashboard with summary statistics and recent items."""
    total_items = MenuItem.objects.count()
    total_categories = Category.objects.count()
    sold_out_count = MenuItem.objects.filter(status=MenuItem.STATUS_SOLD_OUT).count()
    recent_items = MenuItem.objects.order_by("-created_at")[:5]
    context = {
        "total_items": total_items,
        "total_categories": total_categories,
        "sold_out_count": sold_out_count,
        "recent_items": recent_items,
    }
    return render(request, "admin/dashboard.html", context)


@login_required
def add_menu_item(request: HttpRequest) -> HttpResponse:
    """Allow staff to add a new menu item."""
    if request.method == "POST":
        form = MenuItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Menu item created successfully.")
            return redirect(reverse("restaurant:dashboard"))
    else:
        form = MenuItemForm()
    return render(request, "admin/add_item.html", {"form": form})
