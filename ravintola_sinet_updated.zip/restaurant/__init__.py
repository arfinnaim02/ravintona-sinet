"""Application package for restaurant specific logic and models."""
