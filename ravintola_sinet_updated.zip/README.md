# Ravintola Sinet

This repository contains the source code for a premium restaurant website built for **Ravintola Sinet**, located in Joensuu, Finland. The site is powered by **Django** and styled using **Tailwind CSS** with a custom beige/brown/gold colour palette to evoke a rustic yet sophisticated feel. Unlike the default Django admin, a bespoke administration interface allows staff to manage menu items without exposing the underlying framework to customers.

## Features

### Public pages

- **Home** — Hero banner with a welcome message and call‑to‑action buttons, highlights of what makes the restaurant special, a carousel of popular dishes and quick links to different menu categories.
- **Menu** — Filterable list of menu items grouped by category; diners can filter by tags such as *vegan*, *vegetarian* or *spicy*.
- **About** — Brief history of the restaurant, core values and a call to visit.
- **Contact** — Simple contact form to send a message to the restaurant along with address and opening hours.

### Administration

- **Custom login** — Clean, branded login page for staff members.
- **Dashboard** — Overview of menu statistics (total items, categories, sold out), quick actions and a table of recent items.
- **Add menu item** — Form to create new menu entries with support for uploading images, tagging items and marking allergens.

## Getting started

1. **Clone the repository** and change into the project directory:

   ```bash
   git clone <repository-url>
   cd ravintola_sinet
   ```

2. **Create a virtual environment** and install dependencies (Python 3.10 or newer is recommended):

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install django pillow
   ```

3. **Apply migrations** and create a superuser for access to the admin dashboard:

   ```bash
   python manage.py migrate
   python manage.py createsuperuser
   ```

4. **Run the development server**:

   ```bash
   python manage.py runserver
   ```

5. Visit `http://127.0.0.1:8000/` to view the public site and `http://127.0.0.1:8000/admin/login/` for the custom login page.

## Notes

- In development, static and media files are served automatically. For production deployments you should configure a proper web server (e.g. NGINX) to serve these assets.
- The project uses Tailwind via the CDN for convenience. If you wish to compile Tailwind locally, install `tailwindcss` and use the provided `tailwind.config.js`.
- The model definitions support simple comma‑separated tags and allergens. Feel free to normalise these into separate models for more advanced needs.
