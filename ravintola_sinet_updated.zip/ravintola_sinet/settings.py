"""Django settings for the Ravintola Sinet project.

This file contains only the settings required to get the project
running in development. For production deployments you should
override values such as SECRET_KEY, DEBUG, ALLOWED_HOSTS and
database credentials using environment variables or a separate
settings file that isn't committed to version control.
"""

from __future__ import annotations

import os
from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY",
    "django-insecure-change-this-key",  # default fallback for local development
)

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# During development you can allow all hosts. In production you
# should set this to your domain name(s).
ALLOWED_HOSTS: list[str] = ["*"]


# Application definition

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Project apps
    "restaurant",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "ravintola_sinet.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "ravintola_sinet.wsgi.application"


# Database
# https://docs.djangoproject.com/en/4.2/ref/settings/#databases

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}


# Password validation
# https://docs.djangoproject.com/en/4.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]


# Internationalization
# https://docs.djangoproject.com/en/4.2/topics/i18n/

LANGUAGE_CODE = "en-us"

TIME_ZONE = "Asia/Dhaka"

USE_I18N = True

USE_L10N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.2/howto/static-files/

STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"


# Default primary key field type
# https://docs.djangoproject.com/en/4.2/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# Custom settings for the restaurant app

# Tags that can be attached to menu items. These will be presented
# as checkboxes on the menu item creation form.
MENU_ITEM_TAGS: list[tuple[str, str]] = [
    ("vegan", "Vegan"),
    ("vegetarian", "Vegetarian"),
    ("spicy", "Spicy"),
    ("gluten-free", "Gluten Free"),
    ("popular", "Popular"),
]

# Allergen list used on the menu item creation form. You can modify
# this list to reflect the allergens relevant to your menu.
MENU_ITEM_ALLERGENS: list[tuple[str, str]] = [
    ("milk", "Milk"),
    ("egg", "Egg"),
    ("peanut", "Peanut"),
    ("soy", "Soy"),
    ("tree-nut", "Tree Nut"),
    ("wheat", "Wheat"),
    ("fish", "Fish"),
    ("shellfish", "Shellfish"),
]

# Location details for contact page. These values are displayed on
# the contact/about pages and can be customised in one place.
RESTAURANT_NAME = "Ravintola Sinet"
RESTAURANT_ADDRESS = "Joensuu, Finland"
RESTAURANT_PHONE = "+358 123 4567"
RESTAURANT_EMAIL = "info@sinet.fi"
RESTAURANT_OPENING_HOURS = "Mon–Sun 10:00–22:00"

# Login URL used by the @login_required decorator
LOGIN_URL = "/admin/login/"
