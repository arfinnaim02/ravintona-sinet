"""Top level package for the Ravintola Sinet project."""

